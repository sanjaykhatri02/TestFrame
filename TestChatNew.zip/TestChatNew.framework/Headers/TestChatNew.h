//
//  TestChatNew.h
//  TestChatNew
//
//  Created by Sanjay Kumar on 24/09/2024.
//

#import <Foundation/Foundation.h>

//! Project version number for TestChatNew.
FOUNDATION_EXPORT double TestChatNewVersionNumber;

//! Project version string for TestChatNew.
FOUNDATION_EXPORT const unsigned char TestChatNewVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestChatNew/PublicHeader.h>


